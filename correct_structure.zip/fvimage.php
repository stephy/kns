<?php

sleep(2);

echo "<img id=\"fv_pic\" src=\"" . urldecode($_GET["url"]) . "\"/>";

?>