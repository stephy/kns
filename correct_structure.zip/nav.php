<div id="header">

   
   <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-like" data-href="http://www.kevnsteph.com" data-send="false" data-layout="box_count" data-width="50" data-show-faces="true" data-colorscheme="dark" data-font="arial"></div>



<div id="google-ad-header">

<script type="text/javascript"><!--
google_ad_client = "ca-pub-7743840430257018";
/* KevnSteph Header */
google_ad_slot = "6312758749";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>



</div>



</div>


<div id="nav">
    <ul id="navlist">
    <li><a href="index.php" title="Los Angeles Photographers">HOME</a></li>
    <li><a href="portfolio.php">PORTFOLIO</a></li>
    <li><a href="events_gallery.php">EVENTS GALLERY</a></li>
    <li><a href="about_us.php" title="Los Angeles Photographers">ABOUT US</a></li>
    <li><a href="equipment.php">EQUIPMENT</a></li>
    <li><a href="contact_us.php">CONTACT US</a></li>
    </ul>
 </div>